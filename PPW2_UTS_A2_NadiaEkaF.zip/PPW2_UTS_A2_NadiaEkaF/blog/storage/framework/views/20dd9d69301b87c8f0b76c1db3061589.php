

<?php $__env->startSection('title', 'Data Pemain'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <h1>Data Pemain</h1>
    <table border="1px" class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Pemain</th>
                <th>No Punggung</th>
                <th>Posisi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pemain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($player->id); ?></td>
                <td><?php echo e($player->nama_pemain); ?></td>
                <td><?php echo e($player->no_punggung); ?></td>
                <td><?php echo e($player->posisi); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\PPW2_UTS_A2_NadiaEkaF\blog\resources\views/pemain.blade.php ENDPATH**/ ?>